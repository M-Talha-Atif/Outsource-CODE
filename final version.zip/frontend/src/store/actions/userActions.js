import { createAsyncThunk } from "@reduxjs/toolkit";
import userApi from "../../utils/api/userApi";

export const getUsers = createAsyncThunk("user/login", async () => {
  const users = await userApi.getUsers();
  return users;

});

export const getUser = createAsyncThunk("user/login", async (userId) => {
  // console.log("userACTid"+userId)
    const user = await userApi.getUser(userId);
    return user;
  
  });
  
export const login = createAsyncThunk("user/login", async (loginData) => {
  // console.log("in slice", loginData)
    const userId = await userApi.login(loginData);
    // console.log("in slice userid OF USERAction", userId)
    return userId;
  
  });
export const signUp = createAsyncThunk("user/signup", async (signupData) => {
     console.log("in slice", signupData)
      const userCreated = await userApi.createUser(signupData);
       console.log("in slice userid OF USERAction", userCreated)
      return userCreated;
    
    });