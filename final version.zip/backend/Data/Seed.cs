﻿using backend.Models;
using Microsoft.EntityFrameworkCore;

namespace backend.Data
{
    

        public class SeedDataGenerator
        {
            public static void Seed(ModelBuilder builder)
            {
                List<Product> products = new List<Product>();
                products.AddRange(
                    new List<Product>() { 
                new Product() { productID = 1, name = "Product 1", brand = "Brand A", description = "Description of Product 1", imageURL = "https://i5.walmartimages.com/asr/252a28e9-126a-43ac-b59c-2decfe1b2c7c.d805961b1e3737dbee1f4b7cbed1e01e.jpeg" },
                new Product() { productID = 2, name = "Product 2", brand = "Brand B", description = "Description of Product 2", imageURL = "https://i5.walmartimages.com/asr/90893343-6ee7-4f04-a7a4-36473e7e2308.90ff47d4099fcd427d16c6eaabb94f48.jpeg" },
                new Product() { productID = 3, name = "Product 3", brand = "Brand C", description = "Description of Product 3", imageURL = "https://i.pinimg.com/originals/af/d9/6e/afd96ed0cb1984c9c0dfa79fd9376ef1.jpg" },
                new Product() { productID = 4, name = "Product 4", brand = "Brand D", description = "Description of Product 4", imageURL = "https://assetscdn1.paytm.com/images/catalog/product/F/FO/FOONIKE-RUNALLDSMAR26297ED053FA/1563333298007_0..jpg" },
                new Product() { productID = 5, name = "Product 5", brand = "Brand A", description = "Description of Product 5", imageURL = "https://storefeederimages.blob.core.windows.net/heelzsohigh/Products/2355207d-3c80-416d-a822-cd0b641564c0/Full/xygytyukhzk.jpg" },
                new Product() { productID = 6, name = "Product 6", brand = "Brand B", description = "Description of Product 6", imageURL = "https://media.brandalley.co.uk/catalog/product/cache/1/image/900x/c328707a3c432302e119a0cb3e816d26/1/6/16659557-1.jpg" },
                new Product() { productID = 7, name = "Product 7", brand = "Brand C", description = "Description of Product 7", imageURL = "https://cdn.picpng.com/running_shoes/running-shoes-hd-36313.png" },
                new Product() { productID = 8, name = "Product 8", brand = "Brand D", description = "Description of Product 8", imageURL = "https://clipart-library.com/image_gallery/n1023219.png" }
                }
            // Add more products here
            //
            );
               List<ProductSize> productSizes=new List<ProductSize>();
                productSizes.AddRange(
                    new List<ProductSize>() { 
                     // Sizes for Product 1
                     new ProductSize() { productSizeID = 1, size = 35, price = 50.00m, quantity = 10, productID = 1 },
                     new ProductSize() { productSizeID = 2, size = 40, price = 55.00m, quantity = 8, productID = 1 },
                     // Sizes for Product 2
                     new ProductSize() { productSizeID = 3, size = 38, price = 60.00m, quantity = 12, productID = 2 },
                     //size for product 3
                     new ProductSize() { productSizeID = 4, size = 35, price = 30.00m, quantity = 10, productID = 3 },
                     new ProductSize() { productSizeID = 5, size = 40, price = 45.00m, quantity = 8, productID = 3 },
                     // Sizes for Product 4
                     new ProductSize() { productSizeID = 6, size = 39, price = 50.00m, quantity = 10, productID = 4 },
                     new ProductSize() { productSizeID = 7, size = 42, price = 55.00m, quantity = 8, productID = 4 },
                     // Sizes for Product 5
                     new ProductSize() { productSizeID = 8, size = 36, price = 50.00m, quantity = 10, productID = 5 },
                     new ProductSize() { productSizeID = 9, size = 46, price = 55.00m, quantity = 8, productID = 5 },

                     // Sizes for Product 6
                     new ProductSize() { productSizeID = 10, size = 37, price = 50.00m, quantity = 10, productID = 6 },
                     new ProductSize() { productSizeID = 11, size = 47, price = 55.00m, quantity = 8, productID = 6 },
                     // Sizes for Product 7
                     new ProductSize() { productSizeID = 12, size = 35, price = 50.00m, quantity = 10, productID = 7 },
                     new ProductSize() { productSizeID = 13, size = 45, price = 55.00m, quantity = 8, productID = 7 },

                     // Sizes for Product 8
                     new ProductSize() { productSizeID = 14, size = 38, price = 50.00m, quantity = 10, productID = 8 },
                     new ProductSize() { productSizeID = 15, size = 40, price = 55.00m, quantity = 8, productID = 8 }
                    }
                     );
                builder.Entity<Product>().HasData(products);
                builder.Entity<ProductSize>().HasData(productSizes);
            }
        }
 

}