﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace backend.Migrations
{
    /// <inheritdoc />
    public partial class seed : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "ProductSizes",
                columns: new[] { "productSizeID", "price", "productID", "quantity", "size" },
                values: new object[,]
                {
                    { 1, 50.00m, 1, 10, 35 },
                    { 2, 55.00m, 1, 8, 40 },
                    { 3, 60.00m, 2, 12, 38 },
                    { 4, 30.00m, 3, 10, 35 },
                    { 5, 45.00m, 3, 8, 40 },
                    { 6, 50.00m, 4, 10, 39 },
                    { 7, 55.00m, 4, 8, 42 },
                    { 8, 50.00m, 5, 10, 36 },
                    { 9, 55.00m, 5, 8, 46 },
                    { 10, 50.00m, 6, 10, 37 },
                    { 11, 55.00m, 6, 8, 47 },
                    { 12, 50.00m, 7, 10, 35 },
                    { 13, 55.00m, 7, 8, 45 },
                    { 14, 50.00m, 8, 10, 38 },
                    { 15, 55.00m, 8, 8, 40 }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "productID", "brand", "description", "imageURL", "name" },
                values: new object[,]
                {
                    { 1, "Brand A", "Description of Product 1", "https://i5.walmartimages.com/asr/252a28e9-126a-43ac-b59c-2decfe1b2c7c.d805961b1e3737dbee1f4b7cbed1e01e.jpeg", "Product 1" },
                    { 2, "Brand B", "Description of Product 2", "https://i5.walmartimages.com/asr/90893343-6ee7-4f04-a7a4-36473e7e2308.90ff47d4099fcd427d16c6eaabb94f48.jpeg", "Product 2" },
                    { 3, "Brand C", "Description of Product 3", "https://i.pinimg.com/originals/af/d9/6e/afd96ed0cb1984c9c0dfa79fd9376ef1.jpg", "Product 3" },
                    { 4, "Brand D", "Description of Product 4", "https://assetscdn1.paytm.com/images/catalog/product/F/FO/FOONIKE-RUNALLDSMAR26297ED053FA/1563333298007_0..jpg", "Product 4" },
                    { 5, "Brand A", "Description of Product 5", "https://storefeederimages.blob.core.windows.net/heelzsohigh/Products/2355207d-3c80-416d-a822-cd0b641564c0/Full/xygytyukhzk.jpg", "Product 5" },
                    { 6, "Brand B", "Description of Product 6", "https://media.brandalley.co.uk/catalog/product/cache/1/image/900x/c328707a3c432302e119a0cb3e816d26/1/6/16659557-1.jpg", "Product 6" },
                    { 7, "Brand C", "Description of Product 7", "https://cdn.picpng.com/running_shoes/running-shoes-hd-36313.png", "Product 7" },
                    { 8, "Brand D", "Description of Product 8", "https://clipart-library.com/image_gallery/n1023219.png", "Product 8" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "ProductSizes",
                keyColumn: "productSizeID",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "productID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "productID",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "productID",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "productID",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "productID",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "productID",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "productID",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "productID",
                keyValue: 8);
        }
    }
}
